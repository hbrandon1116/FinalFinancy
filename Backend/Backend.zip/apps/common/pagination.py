"""Pagination shared by all list endpoints."""

from rest_framework.pagination import PageNumberPagination


class StandardResultsSetPagination(PageNumberPagination):
    """Standard page/page_size pagination with a documented maximum."""

    page_size = 20
    page_size_query_param = "page_size"
    max_page_size = 100
